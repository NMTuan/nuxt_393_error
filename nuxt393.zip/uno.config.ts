/*
 * @Author: NMTuan
 * @Email: NMTuan@qq.com
 * @Date: 2024-01-29 13:54:07
 * @LastEditTime: 2024-01-29 13:54:19
 * @LastEditors: NMTuan
 * @Description: 
 * @FilePath: \nuxt393\uno.config.ts
 */
// uno.config.ts
import { defineConfig } from 'unocss'

export default defineConfig({
    // ...UnoCSS options
})

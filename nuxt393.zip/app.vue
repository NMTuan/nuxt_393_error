<template>
  <div>
    <!-- <NuxtWelcome /> -->
    <div class="text-3xl text-center p-10 m-10 bg-pink-100">
      test nuxt 3.9.3
    </div>
  </div>
</template>
